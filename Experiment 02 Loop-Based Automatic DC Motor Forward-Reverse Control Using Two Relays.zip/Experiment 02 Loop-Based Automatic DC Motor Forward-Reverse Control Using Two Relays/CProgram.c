#include <reg52.h>

sbit RELAY1_PIN = P3^3;  // Define RELAY1_PIN as P3.3
sbit RELAY2_PIN = P3^7;  // Define RELAY2_PIN as P3.7

void delay_ms(unsigned int ms);

void main(void) {
    while(1) {
        RELAY1_PIN = 1;  // Turn Relay 1 on
        delay_ms(1000);  // Wait for 1 second
        RELAY1_PIN = 0;  // Turn Relay 1 off

        RELAY2_PIN = 1;  // Turn Relay 2 on
        delay_ms(1000);  // Wait for 1 second
        RELAY2_PIN = 0;  // Turn Relay 2 off
    }
}

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i = 0; i < ms; i++) {
        for(j = 0; j < 200; j++) {
            // Adjusted to approximate 1 ms delay for 11.0592 MHz clock
            // Do nothing, just waste time
        }
    }
}
