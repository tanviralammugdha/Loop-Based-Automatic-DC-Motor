#include <REGX52.H>  // Include the header file for AT89S52

void delay_ms(unsigned int ms);  // Function for millisecond delay
void display_digit(unsigned char digit); // Function to display digit on 7-segment

void main()
{
    unsigned char digits[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    int i;

    while (1)
    {
        for (i = 0; i < 10; i++)
        {
            display_digit(digits[i]);
            delay_ms(2000);  // Delay for 2 seconds
        }
    }
}

void delay_ms(unsigned int ms)
{
    unsigned int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 123; j++);  // Approximate delay
}

void display_digit(unsigned char digit)
{
    switch(digit)
    {
        case 0: P1 = 0xC0; break;  // 11000000
        case 1: P1 = 0xF9; break;  // 11111001
        case 2: P1 = 0xA4; break;  // 10100100
        case 3: P1 = 0xB0; break;  // 10110000
        case 4: P1 = 0x99; break;  // 10011001
        case 5: P1 = 0x92; break;  // 10010010
        case 6: P1 = 0x82; break;  // 10000010
        case 7: P1 = 0xF8; break;  // 11111000
        case 8: P1 = 0x80; break;  // 10000000
        case 9: P1 = 0x90; break;  // 10010000
        default: P1 = 0xFF; break;  // All segments off
    }
}
